"use client"

interface Expense {
  id: string
  amount: number
  category: string
  description: string
  date: string
}

interface ExpenseListProps {
  expenses: Expense[]
  onExpenseDeleted: (id: string) => void
}

export default function ExpenseList({ expenses, onExpenseDeleted }: ExpenseListProps) {
  const handleDelete = async (id: string) => {
    try {
      await fetch(`/api/expenses/${id}`, { method: "DELETE" })
      onExpenseDeleted(id)
    } catch (error) {
      console.error("Failed to delete expense:", error)
    }
  }

  const totalAmount = expenses.reduce((sum, exp) => sum + exp.amount, 0)

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Expenses</h2>

      {expenses.length === 0 ? (
        <p className="text-gray-500">No expenses yet. Add one using voice or the form above.</p>
      ) : (
        <>
          <div className="mb-4 p-4 bg-blue-50 rounded-lg">
            <p className="text-gray-600">Total Expenses:</p>
            <p className="text-3xl font-bold text-blue-600">${totalAmount.toFixed(2)}</p>
          </div>

          <div className="space-y-2">
            {expenses.map((expense) => (
              <div
                key={expense.id}
                className="flex justify-between items-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50"
              >
                <div className="flex-1">
                  <p className="font-semibold text-gray-800">{expense.category}</p>
                  <p className="text-sm text-gray-600">{expense.description}</p>
                  <p className="text-xs text-gray-500">{new Date(expense.date).toLocaleDateString()}</p>
                </div>
                <div className="flex items-center gap-4">
                  <p className="text-lg font-bold text-gray-800">${expense.amount.toFixed(2)}</p>
                  <button
                    onClick={() => handleDelete(expense.id)}
                    className="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600 text-sm"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  )
}
