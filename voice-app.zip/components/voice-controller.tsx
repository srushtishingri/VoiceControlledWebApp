"use client"

import { useEffect, useRef } from "react"

interface VoiceControllerProps {
  onCommand: (command: string) => void
  isListening: boolean
  setIsListening: (listening: boolean) => void
  isLoading?: boolean
}

export default function VoiceController({
  onCommand,
  isListening,
  setIsListening,
  isLoading = false,
}: VoiceControllerProps) {
  const recognitionRef = useRef<any>(null)

  useEffect(() => {
    // Initialize Web Speech API
    const SpeechRecognition = window.SpeechRecognition || (window as any).webkitSpeechRecognition

    if (!SpeechRecognition) {
      console.error("Web Speech API not supported")
      return
    }

    const recognition = new SpeechRecognition()
    recognition.continuous = false
    recognition.interimResults = true
    recognition.lang = "en-US"

    recognition.onstart = () => {
      setIsListening(true)
    }

    recognition.onresult = (event: any) => {
      let interimTranscript = ""
      let finalTranscript = ""

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript

        if (event.results[i].isFinal) {
          finalTranscript += transcript + " "
        } else {
          interimTranscript += transcript
        }
      }

      if (finalTranscript) {
        onCommand(finalTranscript.trim())
      }
    }

    recognition.onerror = (event: any) => {
      console.error("Speech recognition error:", event.error)
      setIsListening(false)
    }

    recognition.onend = () => {
      setIsListening(false)
    }

    recognitionRef.current = recognition
  }, [onCommand, setIsListening])

  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop()
    } else {
      recognitionRef.current?.start()
    }
  }

  return (
    <div className="flex gap-4 mb-8 items-center">
      <button
        onClick={toggleListening}
        disabled={isLoading}
        className={`px-6 py-3 rounded-lg font-semibold text-white transition-all disabled:opacity-50 ${
          isListening ? "bg-red-500 hover:bg-red-600 animate-pulse" : "bg-blue-500 hover:bg-blue-600"
        }`}
      >
        {isLoading ? "Processing..." : isListening ? "Listening..." : "Start Listening"}
      </button>
      <p className="text-gray-600">
        {isLoading
          ? "Processing your command..."
          : isListening
            ? "Speak your command..."
            : "Click to start voice control"}
      </p>
    </div>
  )
}
