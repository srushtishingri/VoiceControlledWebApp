"use client"

interface CommandHelpProps {
  onClose: () => void
}

export default function CommandHelp({ onClose }: CommandHelpProps) {
  const commands = [
    {
      category: "Expense Management",
      items: [
        "Add an expense of 50 for groceries",
        "Add 25 dollars for transportation",
        "Show all expenses",
        "List my expenses",
        "Delete expense 1",
      ],
    },
    {
      category: "Navigation",
      items: ["Go to dashboard", "Navigate to analytics", "Open settings"],
    },
    {
      category: "General",
      items: ["Help", "What can I say?"],
    },
  ]

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-lg max-w-2xl w-full max-h-96 overflow-y-auto">
        <div className="sticky top-0 bg-blue-500 text-white p-6 flex justify-between items-center">
          <h2 className="text-2xl font-bold">Available Voice Commands</h2>
          <button onClick={onClose} className="text-2xl hover:opacity-80">
            ×
          </button>
        </div>

        <div className="p-6 space-y-6">
          {commands.map((section) => (
            <div key={section.category}>
              <h3 className="text-lg font-semibold text-gray-800 mb-3">{section.category}</h3>
              <ul className="space-y-2">
                {section.items.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-gray-700">
                    <span className="text-blue-500 font-bold mt-1">•</span>
                    <span className="italic">"{item}"</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
