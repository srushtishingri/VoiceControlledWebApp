import { generateText } from "ai"

/**
 * Parse natural language command using AI
 * Extracts structured data from user voice input
 */
export async function parseNaturalLanguageCommand(command: string) {
  try {
    const { text } = await generateText({
      model: "openai/gpt-4o-mini",
      system: `You are an expert at parsing natural language commands for an expense tracking application.
      
      Extract the following information from the user's command:
      - action: what the user wants to do (add_expense, list_expenses, delete_expense, update_expense)
      - amount: the monetary amount (if applicable)
      - category: expense category like groceries, transportation, entertainment, utilities, etc.
      - description: additional details about the expense
      - date: when the expense occurred (if mentioned)
      
      Respond ONLY with valid JSON:
      {
        "action": string,
        "amount": number | null,
        "category": string | null,
        "description": string | null,
        "date": string | null,
        "confidence": number (0-1)
      }`,
      prompt: command,
    })

    return JSON.parse(text)
  } catch (error) {
    console.error("AI parsing failed:", error)
    throw error
  }
}

/**
 * Generate a natural language response for user feedback
 */
export async function generateFeedbackMessage(action: string, data: any): Promise<string> {
  try {
    const { text } = await generateText({
      model: "openai/gpt-4o-mini",
      prompt: `Generate a friendly, concise confirmation message for this action:
      Action: ${action}
      Data: ${JSON.stringify(data)}
      
      Keep it under 20 words.`,
    })

    return text
  } catch (error) {
    console.error("Feedback generation failed:", error)
    return "Action completed successfully"
  }
}
