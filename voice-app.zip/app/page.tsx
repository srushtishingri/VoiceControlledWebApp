"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import VoiceController from "@/components/voice-controller"
import ExpenseList from "@/components/expense-list"
import ExpenseForm from "@/components/expense-form"
import CommandHelp from "@/components/command-help"

export default function Home() {
  const router = useRouter()
  const [expenses, setExpenses] = useState([])
  const [transcript, setTranscript] = useState("")
  const [isListening, setIsListening] = useState(false)
  const [feedback, setFeedback] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [showHelp, setShowHelp] = useState(false)

  const handleVoiceCommand = async (command: string) => {
    setTranscript(command)
    setFeedback("")
    setError("")
    setIsLoading(true)

    try {
      const response = await fetch("/api/process-command", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ command }),
      })

      const result = await response.json()

      if (result.action === "navigate") {
        setFeedback(`Navigating to ${result.data.page}...`)
        setTimeout(() => {
          router.push(`/${result.data.page}`)
        }, 500)
      } else if (result.action === "help") {
        setShowHelp(true)
        setFeedback("Showing available commands")
      } else if (result.action === "add_expense") {
        const expenseResponse = await fetch("/api/expenses", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            amount: result.data.amount,
            category: result.data.category,
            description: result.data.description || "",
            date: new Date().toISOString(),
          }),
        })

        if (!expenseResponse.ok) throw new Error("Failed to add expense")

        const newExpense = await expenseResponse.json()
        setExpenses([...expenses, newExpense])
        setFeedback(`Successfully added $${result.data.amount} for ${result.data.category}`)
      } else if (result.action === "list_expenses") {
        setFeedback(`Showing ${expenses.length} expenses`)
      } else if (result.action === "delete_expense") {
        const expenseId = result.data.id
        const deleteResponse = await fetch(`/api/expenses/${expenseId}`, { method: "DELETE" })

        if (!deleteResponse.ok) throw new Error("Failed to delete expense")

        setExpenses(expenses.filter((e) => e.id !== expenseId))
        setFeedback("Expense deleted successfully")
      } else {
        setFeedback("Command not recognized. Say 'help' for available commands.")
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Error processing command"
      setError(errorMessage)
      setFeedback("")
      console.error("Command error:", err)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    const fetchExpenses = async () => {
      try {
        const response = await fetch("/api/expenses")
        if (!response.ok) throw new Error("Failed to fetch expenses")
        const data = await response.json()
        setExpenses(data)
      } catch (err) {
        console.error("Failed to fetch expenses:", err)
        setError("Failed to load expenses")
      }
    }

    fetchExpenses()
  }, [])

  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold text-gray-800 mb-2">Voice Expense Tracker</h1>
        <p className="text-gray-600 mb-8">Control your expenses with voice commands</p>

        <VoiceController
          onCommand={handleVoiceCommand}
          isListening={isListening}
          setIsListening={setIsListening}
          isLoading={isLoading}
        />

        {error && <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6 text-red-800">{error}</div>}

        {transcript && (
          <div className="bg-white rounded-lg shadow-md p-4 mb-6 border-l-4 border-blue-500">
            <p className="text-sm text-gray-600">Last Command:</p>
            <p className="text-lg font-semibold text-gray-800">{transcript}</p>
          </div>
        )}

        {feedback && (
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6 text-green-800">{feedback}</div>
        )}

        {showHelp && <CommandHelp onClose={() => setShowHelp(false)} />}

        <ExpenseForm onExpenseAdded={(expense) => setExpenses([...expenses, expense])} />

        <ExpenseList expenses={expenses} onExpenseDeleted={(id) => setExpenses(expenses.filter((e) => e.id !== id))} />
      </div>
    </main>
  )
}
