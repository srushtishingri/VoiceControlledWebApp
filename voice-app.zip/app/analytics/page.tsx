"use client"

import Link from "next/link"

export default function Analytics() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-8">
      <div className="max-w-4xl mx-auto">
        <Link href="/" className="text-blue-500 hover:underline mb-6 inline-block">
          Back to Home
        </Link>
        <h1 className="text-4xl font-bold text-gray-800 mb-8">Analytics</h1>
        <div className="bg-white rounded-lg shadow-md p-6">
          <p className="text-gray-600">Analytics and reports coming soon...</p>
        </div>
      </div>
    </main>
  )
}
