import { type NextRequest, NextResponse } from "next/server"

// In-memory storage reference (same as route.ts)
let expenses: any[] = []

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const initialLength = expenses.length
    expenses = expenses.filter((e) => e.id !== id)

    if (expenses.length === initialLength) {
      return NextResponse.json({ error: "Expense not found" }, { status: 404 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ error: "Failed to delete expense" }, { status: 400 })
  }
}
