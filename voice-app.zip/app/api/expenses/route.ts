import { type NextRequest, NextResponse } from "next/server"

// In-memory storage for demo (replace with database in production)
const expenses: any[] = []
let nextId = 1

export async function GET() {
  return NextResponse.json(expenses)
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const newExpense = {
      id: String(nextId++),
      amount: body.amount,
      category: body.category,
      description: body.description || "",
      date: body.date || new Date().toISOString(),
    }

    expenses.push(newExpense)
    return NextResponse.json(newExpense, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: "Failed to create expense" }, { status: 400 })
  }
}
