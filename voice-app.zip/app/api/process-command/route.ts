import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"

async function parseCommandWithAI(command: string): Promise<{ action: string; data: any }> {
  try {
    const { text } = await generateText({
      model: "openai/gpt-4o-mini",
      system: `You are a command parser for a voice-controlled expense tracker application.
      Parse the user's natural language command and extract the action and data.
      
      Supported actions:
      - add_expense: Add a new expense
      - list_expenses: Show all expenses
      - delete_expense: Delete an expense
      - navigate: Navigate to a page (dashboard, analytics, settings)
      - help: Show help information
      - unknown: Command not recognized
      
      Respond ONLY with valid JSON in this format:
      {
        "action": "add_expense" | "list_expenses" | "delete_expense" | "navigate" | "help" | "unknown",
        "data": {
          "amount": number (if applicable),
          "category": string (if applicable),
          "description": string (if applicable),
          "id": string (if applicable),
          "page": string (if navigation)
        }
      }
      
      Examples:
      - "Add an expense of 500 for groceries" -> {"action": "add_expense", "data": {"amount": 500, "category": "groceries"}}
      - "Show me all expenses" -> {"action": "list_expenses", "data": {}}
      - "Delete expense 1" -> {"action": "delete_expense", "data": {"id": "1"}}
      - "Go to dashboard" -> {"action": "navigate", "data": {"page": "dashboard"}}
      - "Help" -> {"action": "help", "data": {}}`,
      prompt: command,
    })

    const parsed = JSON.parse(text)
    return parsed
  } catch (error) {
    console.error("AI parsing error:", error)
    return parseCommandWithRegex(command)
  }
}

function parseCommandWithRegex(command: string): { action: string; data: any } {
  const lowerCommand = command.toLowerCase()

  // Navigation patterns
  if (
    lowerCommand.includes("go to") ||
    lowerCommand.includes("navigate") ||
    lowerCommand.includes("show") ||
    lowerCommand.includes("open")
  ) {
    if (lowerCommand.includes("dashboard")) {
      return { action: "navigate", data: { page: "dashboard" } }
    }
    if (lowerCommand.includes("analytics") || lowerCommand.includes("report")) {
      return { action: "navigate", data: { page: "analytics" } }
    }
    if (lowerCommand.includes("settings")) {
      return { action: "navigate", data: { page: "settings" } }
    }
  }

  // Help pattern
  if (lowerCommand.includes("help") || lowerCommand.includes("what can i say")) {
    return { action: "help", data: {} }
  }

  // Add expense pattern
  const addExpenseMatch = command.match(
    /add\s+(?:an?\s+)?expense\s+(?:of\s+)?(\d+(?:\.\d{2})?)\s+(?:for\s+)?(.+?)(?:\s+(?:on|yesterday|today|tomorrow))?$/i,
  )

  if (addExpenseMatch) {
    return {
      action: "add_expense",
      data: {
        amount: Number.parseFloat(addExpenseMatch[1]),
        category: addExpenseMatch[2].trim(),
        description: "",
      },
    }
  }

  // List expenses pattern
  if (lowerCommand.includes("list") || lowerCommand.includes("show") || lowerCommand.includes("all expenses")) {
    return { action: "list_expenses", data: {} }
  }

  // Delete expense pattern
  const deleteMatch = command.match(/delete\s+expense\s+(\d+)/i)
  if (deleteMatch) {
    return { action: "delete_expense", data: { id: deleteMatch[1] } }
  }

  return { action: "unknown", data: {} }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const command = body.command

    if (!command) {
      return NextResponse.json({ error: "No command provided" }, { status: 400 })
    }

    const useAI = process.env.OPENAI_API_KEY ? true : false
    const result = useAI ? await parseCommandWithAI(command) : parseCommandWithRegex(command)

    return NextResponse.json(result)
  } catch (error) {
    console.error("Command processing error:", error)
    return NextResponse.json({ error: "Failed to process command" }, { status: 400 })
  }
}
